<!DOCTYPE php>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type= "text/css" href="emploi_du_temps.css">
    <title> emploi_du_temps </title>

</head>

<body>

<center>
<table class="program">
<tr>
    
       <td> MATIERE </td> 
    
    </tr>
    
</table>

</center>

<table class="outer-table" >

    <tr>
        <td>
                <div class="tableau" >

        
    <div class="tableau1">
                                <table border="1" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <td colspan="2">  Lundi </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <td> </td>
                                     <td> </td>
                                     </tbody>
                                </table>
                            </div>
            
                            <div class="tableau1">
                                <table border="1" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <td colspan="2">  Mardi </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <td> </td>
                                     <td> </td>
                                     </tbody>
                                </table>
                            </div>
                            <div class="tableau1">
                                <table border="1" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <td colspan="2">  Mercredi </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <td> </td>
                                     <td> </td>
                                     </tbody>
                                </table>
                            </div>
     
                        <div class="tableau1">
                                <table border="1" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <td   colspan="2">  Jeudi </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <td> </td>
                                     <td> </td>
                                     </tbody>
                                </table>
                            </div>
                            </div>
                  
                   

          <div class="tableau" >
                        <div class="tableau1">
                                <table border="1" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <td colspan="2">  Vendredi </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <td> </td>
                                     <td> </td>
                                     </tbody>
                                </table>
                            </div>

                               <div class="tableau1">
                                <table border="1" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <td colspan="2">  Samedi </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <td> </td>
                                     <td> </td>
                                     </tbody>
                                </table>
                            </div>
                        
        
         

      
        </div>

        </td>
        </tr>


        

          
</table>
      
          
      
      
      
          
       



</body>
</html>